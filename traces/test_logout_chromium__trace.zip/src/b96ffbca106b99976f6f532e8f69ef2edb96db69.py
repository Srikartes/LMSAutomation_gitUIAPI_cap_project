class DashboardPage:
    def __init__(self, page):
        self.page = page

    def get_welcome(self):
        return self.page.locator(".welcome").inner_text()

    def get_course_count(self):
        return self.page.locator(".course-card").count()

    def get_progress(self):
        return self.page.locator(".progress").first.get_attribute("value")

    def logout(self):
        self.page.click("#logout-btn")
