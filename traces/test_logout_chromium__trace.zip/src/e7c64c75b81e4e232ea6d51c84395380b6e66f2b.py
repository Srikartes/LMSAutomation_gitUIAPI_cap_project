import pytest
from pages.login_page import LoginPage
from pages.dashboard_page import DashboardPage
from utils.test_data import TestData


@pytest.mark.ui
@pytest.mark.smoke
def test_valid_login(page, base_url):
    login = LoginPage(page)
    dashboard = DashboardPage(page)
    login.open(base_url)
    login.login(*TestData.VALID_USER)
    page.goto(f"{base_url}/dashboard")
    assert "Welcome" in dashboard.get_welcome()


@pytest.mark.ui
@pytest.mark.regression
@pytest.mark.parametrize("username, password", TestData.INVALID_USERS)
def test_invalid_login(page, base_url, username, password):
    login = LoginPage(page)
    login.open(base_url)
    login.login(username, password)
    assert "Invalid" in login.get_error()


@pytest.mark.ui
@pytest.mark.regression
def test_logout(page, base_url):
    dashboard = DashboardPage(page)
    page.goto(f"{base_url}/dashboard")
    dashboard.logout()
    assert page.locator("#login-btn").is_visible()
    assert False